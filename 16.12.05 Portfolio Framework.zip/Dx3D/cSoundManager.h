#pragma once
class cSoundManager
{
private:

public:
	cSoundManager();
	~cSoundManager();
};

