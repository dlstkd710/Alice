#pragma once
class Water
{
private:
	std::vector<ST_PT_VERTEX>	m_vecVertex;
	LPD3DXEFFECT				m_pEffect;


	LPDIRECT3DTEXTURE9		m_ptexture;
	LPDIRECT3DTEXTURE9		m_ptexture1;


	float  a;
public:
	Water();
	~Water();

public:
	virtual void Setup();
	virtual void Render();

	LPD3DXEFFECT LoadEffect(const char* szFileName);
};

